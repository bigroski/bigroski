<html>
<head>
<script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
<script src="codemirror-3.13/lib/codemirror.js"></script>
<link rel="stylesheet" href="codemirror-3.13/lib/codemirror.css">
<script src="codemirror-3.13/mode/javascript/javascript.js"></script>
<script>
 var myCodeMirror = CodeMirror(document.body);
</script>
</head>
<body>
    
</body>
</html>