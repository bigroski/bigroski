<?php

echo "<script>location.href='../../index.php'</script>"

?>