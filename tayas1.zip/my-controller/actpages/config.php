<?php
//Get this value from http://grabz.it/api
$grabzItApplicationKey = "cHJhdGlrLnJhZ2h1YmFuc2hpQGdtYWlsLmNvbQ==";
//Get this value from http://grabz.it/api
$grabzItApplicationSecret = "Pz8/P3s/PzR6Pz8wPz8HOnU/P35zPyVvZzQ/ZT8/Jko=";
//The absolute path that you have placed the handler.php on your website
$grabzItHandlerUrl = "http://localhost/gabisamodel/php/";
?>