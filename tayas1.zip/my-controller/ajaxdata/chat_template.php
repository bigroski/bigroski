<div class="client_chat" id="<?php echo $_GET['client_name']; ?>">
    <div class="chat_header">
        <div class="chat_client_name">
            <?php echo $_GET['client_name']; ?>
        </div>
        <div class="chat_buttons">
            <a href="javascript:void(0)" class="min_chat">__</a>
            <a href="javascript:void(0)" class="max_chat">[]</a>
        </div>
    </div>
    <div class="chat_body">
        <div class="chat_text_area">
            <div class="chat_line">
                <p>
                    <b>Name:</b>
                    Yolo Chat
                </p>
                <p>
                    <b>Another Name:</b>
                    Yolo Yolo
                </p>
                
            </div>
            <div class="chat_line">
                <p>
                    <b>new ChatLine:</b>
                    Yolo Chat
                </p>
                
                
            </div>
        </div>
        <div class="chat_text_box">
            <textarea class="chat_text" name="chat_text"></textarea>
        </div>
    </div>
</div>