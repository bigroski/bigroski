<div class="clear"></div>
<div id="footer">
  <div class="copyright">Copyright &copy; 2005 - 2013 Tayaş Gıda A.Ş. All Rights Reserved </div>
  <div class="clear"></div>
</div>
