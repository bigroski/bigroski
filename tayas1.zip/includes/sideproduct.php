<div id="urunkat">
      <div class="baslik">PRODUCTS</div>
      <div class="clear"></div>
      <div class="kategoriler">
        <div style="line-height:20px; background-color:#f1f0f0; border:1px solid #cccccc; padding-left:10px;"><a href="subcategory.php" style="color:#FF0000">CANDIES</a></div>
        <div class="clear"></div>
        <div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Eclairs</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Soft Candies With Filling</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Soft Candies</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Hard Candies</a></div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div style="line-height:20px; background-color:#f1f0f0; border:1px solid #cccccc; padding-left:10px;"><a href="subcategory.php" style="color:#FF0000">COMPOUND CHOCOLATES</a></div>
        <div class="clear"></div>
        <div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Products with Biscuits</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Bars</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Gift Products</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Tablets</a></div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div style="line-height:20px; background-color:#f1f0f0; border:1px solid #cccccc; padding-left:10px;"><a href="subcategory.php" style="color:#FF0000">CHOCOLATES</a></div>
        <div class="clear"></div>
        <div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Bars</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Gift Products</a></div>
          <div class="clear"></div>
          <div style="width:200px; margin-left:20px; line-height:20px;"><a href="producttype.php">>>Tablets</a></div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div style="line-height:20px; background-color:#f1f0f0; border:1px solid #cccccc; padding-left:10px;"><a href="subcategory.php" style="color:#FF0000">SPREAD CHOCOLATES</a></div>
        <div class="clear"></div>
        <div> </div>
        <div class="clear"></div>
      </div>
    </div>